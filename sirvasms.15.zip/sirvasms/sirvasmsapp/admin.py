# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

# Register your models here.
from sirvasmsapp.models import SMS
from sirvasmsapp.models import Email
from sirvasmsapp.models import DateRange
from sirvasmsapp.models import Rate

admin.site.register(SMS)
admin.site.register(Email)
admin.site.register(DateRange)
admin.site.register(Rate)