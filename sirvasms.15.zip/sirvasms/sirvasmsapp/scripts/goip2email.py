import mysql.connector

# Marrow Mailer
import logging
from marrow.mailer import Message, Mailer
logging.basicConfig(level=logging.DEBUG)


def getEmail(number): # Last Person who send SMS to this number
  
      conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
      cursor = conn.cursor()
      sql = "SELECT from_email FROM sirvasmsapp_email WHERE subject = '{}' order by id desc LIMIT 1".format(number)
      cursor.execute(sql)
      row = cursor.fetchone()

      if row:
          email = str(row[0])
          return email
      else:
          return "joven@starhub.com.ph"
        
def getRates(number):
  
        if "+63" in number: # PHILIPPINES
            get_code = "+63"
        elif "+1" in number: # US and CANADA
            get_code = "+1"
        elif "+65" in number: # SINGAPORE
            get_code = "+65"
        elif "+971" in number: # UAE 
            get_code = "+971"
        elif "+852" in number: # HONGKONG
            get_code = "+852"
        elif "+86" in number: # CHINA
            get_code = "+86"
        elif "+60" in number: # MALAYSIA
            get_code = "+60"
        elif "+91" in number: # INDIA
            get_code = "+91"
        else: # OTHER COUNTRIES
            get_code = "+000"

        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
        cursor = conn.cursor()
        sql = "select buy,sell from sirvasmsapp_rate WHERE code LIKE '{}%'".format(get_code)
        cursor.execute(sql)
        row = cursor.fetchone()

        if row:
            buy = str(row[0])
            sell = str(row[1])  
        else:
            buy = "0"
            sell = "0"
            
        rates = {"buy":buy,"sell":sell}
        return rates
  
def updateStatus(_id,status):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='goip')
        cursor = conn.cursor()
        sql = "UPDATE receive SET twilio_status = '{}' WHERE id = '{}'".format(status,_id)
        cursor.execute(sql)
        conn.commit()
        conn.close()
        
def insertSMS(from_number, to_number, body, MessageSid, smsStatus, from_country, to_country, forwarded_to):
  
        rates = getRates(to_number)
        buy = rates["buy"]
        sell = rates["sell"]
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
        cursor = conn.cursor()
        sql = "INSERT INTO sirvasmsapp_sms (id, from_number, to_number, body, route, MessageSid, smsStatus, from_country, to_country, forwarded_to, buy, sell, date) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP())"
        cursor.execute(sql, ('AUTO',from_number, to_number, body, "GSM", MessageSid, smsStatus, from_country, to_country, forwarded_to, buy, sell))
        conn.commit()
        conn.close()

# ======================================================================================
# FETCH EMAIL FROM DJANGO_MAIL WHERE TWILIO_STATUS = 0
# ======================================================================================
conn = mysql.connector.Connect(host='localhost',user='root',password='',database='goip')
cursor = conn.cursor()
sql = "SELECT * FROM receive WHERE twilio_status = '0' LIMIT 1;" 
cursor.execute(sql)
row = cursor.fetchone()

if row:
      
      _id = str(row[0])
      srcnum = str(row[1])
      msg = str(row[3])
      date = str(row[4])
      
      email = getEmail(srcnum)
      
      mail = Mailer({
            'manager.use': 'futures',
            'transport.use': 'smtp',
            'transport.host': 'smtp.gmail.com',
            'transport.tls': 'ssl',
            'transport.username': 'servicehub.sms@gmail.com',
            'transport.password': '09106850351',
            'transport.max_messages_per_connection': 5
          })
      mail.start()

      message = Message([('ServiceHub', 'servicehub.sms@gmail.com')], [(email,email)], srcnum, plain=msg)

      mail.send(message)
      mail.stop()
      
      updateStatus(_id,1)
      insertSMS(srcnum, "+639178895424 ", msg, _id, "received", "PH", "PH", email)




