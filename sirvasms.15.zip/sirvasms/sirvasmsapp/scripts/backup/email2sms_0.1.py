from twilio.rest import Client

import mysql.connector
import base64
import email
import mailparser
import time


def updateStatus(email_id):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
        cursor = conn.cursor()
        sql = "UPDATE django_mailbox_message SET twilio_status = '1' WHERE id = '{}'".format(email_id)
        cursor.execute(sql)
        conn.commit()
        conn.close()

def insertEmail(from_email, to_email, subject, body, MessageSid):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
        cursor = conn.cursor()
        sql = "INSERT INTO sirvasmsapp_email (id, from_email, to_email, subject, body, MessageSid) VALUES (%s, %s, %s, %s, %s, %s)"
        number_of_rows = cursor.execute(sql, ('AUTO',from_email, to_email, subject, body, MessageSid))
        conn.commit()
        conn.close()
        
conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
cursor = conn.cursor()
sql = "SELECT id,body FROM django_mailbox_message WHERE twilio_status = '0' LIMIT 1;"
cursor.execute(sql)
row = cursor.fetchone()

if row:

      id_ = str(row[0])
      body = str(row[1])

      a = body
      b = base64.b64decode(a)

      mail = mailparser.parse_from_bytes(b)

      from_ = mail.from_
      from_ = from_[0][1]
      to = mail.to
      to = to[0][1]
      subject = mail.subject
      body = mail.body

      sep = '--- mail_boundary ---'
      body = body.split(sep, 1)[0]



      # Your Account SID from twilio.com/console
      account_sid = "ACe4a77d8aa2fc0c6c53d1710010ec6d11"
      auth_token  = "6a2597349081c45d3bfbb577a6a97ce9"
      client = Client(account_sid, auth_token)

      message = client.messages.create(
          to=subject,
          from_="+12564454279",
          body=body)
      
      updateStatus(id_)
      insertEmail(from_, to, subject, body, message.sid)
      

else:

      print("No Email to Fetch")
