from twilio.rest import Client

import mysql.connector
import base64
import email
import mailparser
import time
import re

def updateStatus(status,email_id):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
        cursor = conn.cursor()
        sql = "UPDATE django_mailbox_message SET twilio_status = '{}' WHERE id = '{}'".format(status,email_id)
        cursor.execute(sql)
        conn.commit()
        conn.close()

def insertEmail(from_email, to_email, subject, body, MessageSid):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
        cursor = conn.cursor()
        sql = "INSERT INTO sirvasmsapp_email (id, from_email, to_email, subject, body, MessageSid) VALUES (%s, %s, %s, %s, %s, %s)"
        number_of_rows = cursor.execute(sql, ('AUTO',from_email, to_email, subject, body, MessageSid))
        conn.commit()
        conn.close()
        
def twilio_send(subject,from_,body):
      # Your Account SID from twilio.com/console
      account_sid = "ACe4a77d8aa2fc0c6c53d1710010ec6d11"
      auth_token  = "6a2597349081c45d3bfbb577a6a97ce9"
      client = Client(account_sid, auth_token)
      
      message = client.messages.create(
          to=subject,
          from_="+12564454279",
          body=body)
      
      return message.sid
    
def regex_subject(subject):

      regex = r"([+]|[0-9]){5,20}"
      matches = re.finditer(regex, subject, re.MULTILINE)

      for matchNum, match in enumerate(matches):
          matchNum = matchNum + 1

          return (match.group())
        
# ======================================================================================
# FETCH EMAIL FROM DJANGO_MAIL WHERE TWILIO_STATUS = 0
# ======================================================================================
conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
cursor = conn.cursor()
sql = "SELECT id,body FROM django_mailbox_message WHERE twilio_status = '0' LIMIT 1;"
cursor.execute(sql)
row = cursor.fetchone()

if row:

      id_ = str(row[0])
      body = str(row[1])

      # =================================================================================
      # DECODE BODY
      # =================================================================================
      decoded = base64.b64decode(body)
      mail = mailparser.parse_from_bytes(decoded)

      # =================================================================================
      # GET EMAIL DATA
      # =================================================================================
      from_ = mail.from_
      from_ = from_[0][1]
      
      to = mail.to
      to = to[0][1]
      
      print("mailbox_id: " + id_)
      print("from: " + from_)
      print("To: " + to)

      subject = mail.subject
      print("Subject: " + subject)
      
      regex_subject = regex_subject(subject)
      
      body = mail.body
      print("Body: " + body)

      sep = '--- mail_boundary ---'
      body = body.split(sep, 1)[0]
      print("Sep Body: " + body)

      
      if regex_subject:
        
          messageSid = twilio_send(regex_subject,from_,body) # Send SMS and Get MessageSID
          
          if messageSid:
              updateStatus('1',id_) # Update Django Mail Twilio_Status
              insertEmail(from_, to, regex_subject, body, messageSid) # Insert Email Record to Django
          else:
              updateStatus('3',id_) 
              insertEmail(from_, to, regex_subject, body, messageSid) 
              
        
      elif regex_subject is None:
           updateStatus('2',id_) 
           insertEmail(from_, to, subject, body, "Invalid Subject") 
      

else:

      print("No Email to Fetch")
