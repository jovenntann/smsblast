from django.shortcuts import render
from django.http import HttpResponse

from django.utils import timezone

# Redirect to External Links
from django.shortcuts import redirect

# TWILIO
from twilio.rest import Client

# Marrow Mailer
import logging
from marrow.mailer import Message, Mailer
logging.basicConfig(level=logging.DEBUG)

# Login and Logout
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from sirvasms import settings
from django.contrib.auth.decorators import login_required

# Models
from django.db.models import Q
from django.db.models import Sum
from django.db.models import Count

from sirvasmsapp.models import SMS
from sirvasmsapp.models import Email
from sirvasmsapp.models import DateRange
from sirvasmsapp.models import Rate

from django.views.decorators.csrf import csrf_exempt, csrf_protect

# Buy and Sell Computation
from decimal import Decimal, getcontext

# For Graph 
import calendar
from datetime import timedelta, date
import datetime
from collections import OrderedDict

def twilio_send(number,body):
      # Your Account SID from twilio.com/console
      account_sid = "ACe4a77d8aa2fc0c6c53d1710010ec6d11"
      auth_token  = "6a2597349081c45d3bfbb577a6a97ce9"
      client = Client(account_sid, auth_token)

      message = client.messages.create(
          to=number,
          # from_="+12564454279",
          from_="SIRVA",
          body=body)
     
    
def getRates(subject): # THIS IS INCOMING MESSAGE RATES
  
         if "+63" in subject: # PHILIPPINES
            buy = "0"
            sell = "0"
          
         elif "+1" in subject: # US and CANADA
          
            buy = "0.075"
            sell = "0.15"
            
         elif "+65" in subject: # SINGAPORE
          
            buy = "0.05"
            sell = "0.10"
            
         elif "+971" in subject: # UAE
          
            buy = "0.031"
            sell = "0.062"
            
         elif "+852" in subject: # HONGKONG`
          
             buy = "0.06283"
             sell = "0.12566"
              
         elif "+60" in subject: # MALAYSIA
          
             buy = "0.040300"
             sell = "0.080600"
              
         elif "+91" in subject: # INDIA
          
             buy = "0.010000"
             sell = "0.020000"
              
         else: # OTHER COUNTRY
          
             buy = "0.075"
             sell = "0.075"
            
         rates = {"buy":buy,"sell":sell}
         return rates
         
      
def Login(request): #login is reserved word -- strictly use Login :)
  
  
    if request.user.is_superuser:
        next = request.GET.get('next', '/portal/home')
    else: 
        next = request.GET.get('next', '/portal/reports')
    
    
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)

        if user is not None:
            if user.is_active:
                login(request, user)
                return HttpResponseRedirect(next)
            else:
                return HttpResponse("Inactive user.")
        else:
            return HttpResponseRedirect(settings.LOGIN_URL)

    return render(request, "sirvasmsapp/login.html", {'redirect_to': next})

@login_required
def Logout(request):
    logout(request)
    return HttpResponseRedirect(settings.LOGIN_URL)

@login_required
def index(request):
    return HttpResponseRedirect('portal/home/')
  
@login_required
def home(request):
  
    # Get Current Logged-in User ID
    current_user = request.user
    user_id = current_user.id
    
    if request.user.is_superuser:
        
          daterange_get = DateRange.objects.get(id=user_id)
          date_from = str(daterange_get.date_from)
          date_to = str(daterange_get.date_to)

          current_url = "/portal/home"

          sent_buy = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('buy'))
          sent_buy = sent_buy['buy__sum']

          sent_sell = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('sell'))
          sent_sell = sent_sell['sell__sum']

          received_buy = SMS.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('buy'))
          received_buy = received_buy['buy__sum']

          received_sell = SMS.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('sell'))
          received_sell = received_sell['sell__sum']

          getcontext().prec = 6

          total_buy = Decimal(sent_buy) + Decimal(received_buy)
          total_sell = Decimal(sent_sell) + Decimal(received_sell)

          total_earnings = Decimal(total_sell) - Decimal(total_buy)
          total_earnings_php = Decimal(total_earnings) * Decimal(52.91)
          
          # GRAPH USAGE PER COUNTRY #######################################################################################################################
          
          countries = Rate.objects.all()
          
          graph_list = []
          
          for x in countries:
            
              total_sent = Email.objects.filter(Q(date__range=[date_from, date_to]),Q(subject__icontains=x.code)).order_by('id').aggregate(Sum('sell'))
              total_sent = total_sent['sell__sum']

              total_received = SMS.objects.filter(Q(date__range=[date_from, date_to]),Q(to_number__icontains=x.code)).order_by('id').aggregate(Sum('sell'))
              total_received = total_received['sell__sum']

              if total_sent is None:
                  total_sent = 0.0000

              if total_received is None:
                  total_received = 0.0000

              graph_dict = {'country':x,'total_sent':total_sent,'total_received':total_received}
              graph_list.append(dict(graph_dict))
              
              
          # GRAPH LAST 30 DAYS ##############################################################################################################################   
          
          def daterange(start_date, end_date):
              for n in range(int ((end_date - start_date).days)):
                  yield start_date + timedelta(n)
               
          start_date = date(int(daterange_get.date_from.strftime("%Y")), int(daterange_get.date_from.strftime("%m")), int(daterange_get.date_from.strftime("%d")))
          end_date = date(int(daterange_get.date_to.strftime("%Y")), int(daterange_get.date_to.strftime("%m")), int(daterange_get.date_to.strftime("%d")))

          graph_date_list = []
          graph_date_dict = {}
          
          for single_date in daterange(start_date, end_date):
                          
              total_sent = Email.objects.filter(Q(date__range=[single_date, single_date + timedelta(days=1)])).order_by('id').aggregate(Sum('sell'))
              total_sent = total_sent['sell__sum']
              
              total_received = SMS.objects.filter(Q(date__range=[single_date, single_date + timedelta(days=1)])).order_by('id').aggregate(Sum('sell'))
              total_received = total_received['sell__sum']
              
              if total_sent is None:
                  total_sent = 0.0000
                  
              if total_received is None:
                  total_received = 0.0000

              graph_date_dict = {'date':single_date.strftime("%Y-%m-%d"),'total_sent':total_sent,'total_received':total_received}
              graph_date_list.append(dict(graph_date_dict))
          
          
          home_context = {
              'current_url':current_url,
              'date_from':date_from,
              'date_to':date_to,
              'total_buy':total_buy,
              'total_sell':total_sell,
              'total_earnings':total_earnings,
              'total_earnings_php':total_earnings_php,
              'activate':'home',
              'graph_list':graph_list,
              'graph_date_list':graph_date_list,
          }

          return render(request,'sirvasmsapp/home.html', context=home_context)
        
    else:
      
          daterange_get = DateRange.objects.get(id=user_id)
          date_from = str(daterange_get.date_from)
          date_to = str(daterange_get.date_to)

          current_url = "/portal/home"
          
          count_total = "1601"

          sent_total = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('sell'))
          sent_total = sent_total['sell__sum']
          

          getcontext().prec = 6

          total_php = Decimal(sent_total) * Decimal(52.91)
          
          
          # GRAPH USAGE PER COUNTRY #######################################################################################################################
          
          countries = Rate.objects.all()
          
          graph_costs = {}
          
          for x in countries:
            
            total_country = Email.objects.filter(Q(date__range=[date_from, date_to]),Q(subject__icontains=x.code)).order_by('id').aggregate(Sum('sell'))
            total_country = total_country['sell__sum']
          
            if total_country is None:
                total_country = 0.0000
            
            graph_costs.update({x.country:total_country})
                                
                                
          # GRAPH LAST 30 DAYS ##############################################################################################################################   
          
          def daterange(start_date, end_date):
              for n in range(int ((end_date - start_date).days)):
                  yield start_date + timedelta(n)
               
          start_date = date(int(daterange_get.date_from.strftime("%Y")), int(daterange_get.date_from.strftime("%m")), int(daterange_get.date_from.strftime("%d")))
          end_date = date(int(daterange_get.date_to.strftime("%Y")), int(daterange_get.date_to.strftime("%m")), int(daterange_get.date_to.strftime("%d")))

          graph_dates_values = {}
          
          for single_date in daterange(start_date, end_date):
                          
              graph_sent_total = Email.objects.filter(Q(date__range=[single_date, single_date + timedelta(days=1)])).order_by('id').aggregate(Sum('sell'))
              graph_sent_total = graph_sent_total['sell__sum']
              
              if graph_sent_total is None:
                  graph_sent_total = 0.0000
         
              graph_dates_values.update({single_date.strftime("%Y-%m-%d"):str(graph_sent_total)})
          

          graph_dates_values = OrderedDict(sorted(graph_dates_values.items(), key=lambda t: t[0]))
          usage_per_user = Email.objects.values('from_email').order_by('from_email').annotate(total=Sum('sell'))
          
          home_context = {
              'current_url':current_url,
              'date_from':date_from,
              'date_to':date_to,
              'sent_total':sent_total,
              'count_total':count_total,
              'total_php':total_php,
              'activate':'home',
              'countries':countries,
              'graph_costs':graph_costs,
              'graph_dates_values':graph_dates_values,
              'usage_per_user':usage_per_user,
          }

          return render(request,'sirvasmsapp/home_user.html', context=home_context)
  
  
  
  
@login_required
def daterange_submit(request):
        
    date_from = request.POST['from']
    date_to = request.POST['to']
    current_url = request.POST['current_url']
    
    # Get Current Logged-in User ID
    current_user = request.user
    user_id = current_user.id
    
    DateRange.objects.filter(id=user_id).update(date_from = date_from, date_to = date_to)

    return HttpResponseRedirect(current_url)
  
@csrf_exempt  
def api(request):
  
      if request.method == "GET":
      
        from_number = request.GET['From']
        to_number = request.GET['To']
        body = request.GET['Body']
        MessageSid = request.GET['SmsMessageSid']
        smsStatus = request.GET['SmsStatus']
        from_country = request.GET['FromCountry']
        to_country = request.GET['ToCountry']
        
        from_email = Email.objects.filter(subject=from_number).values('from_email').order_by('-id')[:1]
        
        if from_email:
            forwarded_to = from_email[0]['from_email']
        else:
            forwarded_to = "joven@starhub.com.ph"

  
        mail = Mailer({
              'manager.use': 'futures',
              'transport.use': 'smtp',
              'transport.host': 'smtp.gmail.com',
              'transport.tls': 'ssl',
              'transport.username': 'servicehub.sms@gmail.com',
              'transport.password': '09106850351',
              'transport.max_messages_per_connection': 5
            })
        mail.start()

        # message = Message([('ServiceHub', 'joven@telerain.com')], [('Joven Tan', 'jovenntann@gmail.com')], from_number, plain=body)
        message = Message([('ServiceHub', 'servicehub.sms@gmail.com')], [(forwarded_to,forwarded_to)], from_number, plain=body)

        mail.send(message)
        mail.stop()
        
        rates = getRates(to_number)
        buy = rates["buy"]
        sell = rates["sell"]
        
        user_object = SMS(from_number = from_number, to_number = to_number, body = body, MessageSid = MessageSid, smsStatus = smsStatus, from_country = from_country, to_country = to_country, forwarded_to = forwarded_to, buy = buy, sell = sell, route = "Twilio")
        user_object.save()
        
        return HttpResponse(body)
      
@login_required
def received(request):
  
    # Get Current Logged-in User ID
    current_user = request.user
    user_id = current_user.id
        
    if request.user.is_superuser:
  
          # Get Current Logged-in User ID
          current_user = request.user
          user_id = current_user.id

          daterange_get = DateRange.objects.get(id=user_id)
          date_from = str(daterange_get.date_from)
          date_to = str(daterange_get.date_to)

          current_url = "/portal/received/"

          # received_lists = SMS.objects.filter().order_by('-id')
          received_lists = SMS.objects.filter(Q(date__range=[date_from, date_to])).order_by('-id')

          received_buy = SMS.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('buy'))
          received_buy = received_buy['buy__sum']

          received_sell = SMS.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('sell'))
          received_sell = received_sell['sell__sum']

          getcontext().prec = 6
          received_earnings = Decimal(received_sell) - Decimal(received_buy) 
          received_earnings_php = Decimal(received_earnings) * Decimal(53.02)

          context = {
               'current_url':current_url,
               'date_from':date_from,
               'date_to':date_to,
               'received_lists':received_lists,
               'received_buy':received_buy,
               'received_sell':received_sell,
               'received_earnings':received_earnings,
               'received_earnings_php':received_earnings_php,
               'activate':'received',
          }
          return render(request,'sirvasmsapp/received.html',context=context)
        
    else:
      
          daterange_get = DateRange.objects.get(id=user_id)
          date_from = str(daterange_get.date_from)
          date_to = str(daterange_get.date_to)

          current_url = "/portal/received/"

          # received_lists = SMS.objects.filter().order_by('-id')
          received_lists = SMS.objects.filter(Q(date__range=[date_from, date_to])).order_by('-id')

          received_buy = SMS.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('buy'))
          received_buy = received_buy['buy__sum']

          received_sell = SMS.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('sell'))
          received_sell = received_sell['sell__sum']

          getcontext().prec = 6
          received_earnings = Decimal(received_sell) - Decimal(received_buy) 
          received_earnings_php = Decimal(received_earnings) * Decimal(53.02)

          context = {
               'current_url':current_url,
               'date_from':date_from,
               'date_to':date_to,
               'received_lists':received_lists,
               'received_buy':received_buy,
               'received_sell':received_sell,
               'received_earnings':received_earnings,
               'received_earnings_php':received_earnings_php,
               'activate':'received',
          }
          return render(request,'sirvasmsapp/received_user.html',context=context)
  
@login_required
def sent(request):
  
    # Get Current Logged-in User ID
    current_user = request.user
    user_id = current_user.id
    
    if request.user.is_superuser:
       
          daterange_get = DateRange.objects.get(id=user_id)
          date_from = str(daterange_get.date_from)
          date_to = str(daterange_get.date_to)

          current_url = "/portal/sent/" 

          # email_lists = Email.objects.filter().order_by('-id')
          email_lists = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('-id')

          sent_buy = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('buy'))
          sent_buy = sent_buy['buy__sum']

          sent_sell = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('sell'))
          sent_sell = sent_sell['sell__sum']

          getcontext().prec = 6
          sent_earnings = Decimal(sent_sell) - Decimal(sent_buy)  
          sent_earnings_php = Decimal(sent_earnings) * Decimal(53.02)

          context = {
               'current_url':current_url,
               'date_from':date_from,
               'date_to':date_to,
               'email_lists':email_lists,
               'sent_buy':sent_buy,
               'sent_sell':sent_sell,
               'sent_earnings':sent_earnings,
               'sent_earnings_php':sent_earnings_php,
               'activate':'sent',
          }
          return render(request,'sirvasmsapp/sent.html',context=context)
  
    else:
          
          daterange_get = DateRange.objects.get(id=user_id)
          date_from = str(daterange_get.date_from)
          date_to = str(daterange_get.date_to)

          current_url = "/portal/sent/" 

          # email_lists = Email.objects.filter().order_by('-id')
          email_lists = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('-id')

          sent_buy = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('buy'))
          sent_buy = sent_buy['buy__sum']

          sent_sell = Email.objects.filter(Q(date__range=[date_from, date_to])).order_by('id').aggregate(Sum('sell'))
          sent_sell = sent_sell['sell__sum']

          getcontext().prec = 6
          sent_earnings = Decimal(sent_sell) - Decimal(sent_buy)  
          sent_earnings_php = Decimal(sent_earnings) * Decimal(53.02)

          context = {
               'current_url':current_url,
               'date_from':date_from,
               'date_to':date_to,
               'email_lists':email_lists,
               'sent_buy':sent_buy,
               'sent_sell':sent_sell,
               'sent_earnings':sent_earnings,
               'sent_earnings_php':sent_earnings_php,
               'activate':'sent',
          }
          return render(request,'sirvasmsapp/sent_user.html',context=context)
      

@login_required
def reports(request):
  
    current_user = request.user
    user_id = current_user.id
    
    daterange_get = DateRange.objects.get(id=user_id)
    date_from = str(daterange_get.date_from)
    date_to = str(daterange_get.date_to)

    current_url = "/portal/reports/" 

    usage_per_user = Email.objects.values('from_email').order_by('from_email').annotate(total=Sum('sell')) 
    
    usage_per_users = Email.objects.order_by('from_email').values_list('from_email', flat=True).distinct()
    
    reports_list = []
    
    for x in usage_per_users:
      
        total = Email.objects.filter(Q(date__range=[date_from, date_to]),Q(from_email=x)).values('from_email').order_by('from_email').annotate(total=Sum('sell')) 
        
        if total:
            total = total[0]['total']
        else:
            total = 0
        
        count = Email.objects.filter(Q(date__range=[date_from, date_to]),Q(from_email=x))
        count = count.count()
        
        reports_dict = {'from_email':x,'count':count,'total':total}
        reports_list.append(dict(reports_dict))

            
    context = {
         'current_url':current_url,
         'date_from':date_from,
         'date_to':date_to,
         'reports_list':reports_list,
         'activate':'reports',
    }
    
    if request.user.is_superuser:
        return render(request,'sirvasmsapp/reports.html',context=context)
    else:
        return render(request,'sirvasmsapp/reports_user.html',context=context)
  
@login_required
def usage(request, email):
  
    # Get Current Logged-in User ID
    current_user = request.user
    user_id = current_user.id
    
    daterange_get = DateRange.objects.get(id=user_id)
    date_from = str(daterange_get.date_from)
    date_to = str(daterange_get.date_to)
    
    total_usage = Email.objects.filter(Q(date__range=[date_from, date_to]),Q(from_email=email)).values('from_email').order_by('from_email').annotate(total=Sum('sell')) 
    
    if total_usage:
        total_usage = total_usage[0]['total']
    else:
        total_usage = 0
            
    current_url = "/portal/usage/" + email + "/"

    countries = Rate.objects.all()

    countries_list = []
    countries_dict = {}

    for x in countries:

        costs = Email.objects.filter(Q(date__range=[date_from, date_to]),Q(subject__icontains=x.code),Q(from_email=email)).order_by('id').aggregate(Sum('sell'))
        costs = costs['sell__sum']
        
        count = Email.objects.filter(Q(date__range=[date_from, date_to]),Q(subject__icontains=x.code),Q(from_email=email))
        count = count.count()

        if costs is None:
            costs = 0.0000
            
        if count is None:
            count = 0

        countries_dict = {'country':x,'count':count,'costs':costs}
        countries_list.append(dict(countries_dict))

            
    context = {
         'current_url':current_url,
         'date_from':date_from,
         'date_to':date_to,
         'countries_list':countries_list,
         'activate':'reports',
         'email':email,
         'total_usage':total_usage,
    }
    
    if request.user.is_superuser:
        return render(request,'sirvasmsapp/usage.html',context=context)
    else:
        return render(request,'sirvasmsapp/usage_user.html',context=context)
  
  
@login_required
def sendsms(request):
        
    number = request.POST['number']
    message = request.POST['message']
    twilio_send(number,message)
      
    return HttpResponseRedirect('/portal/sent/')
      
    
    

def error_404(request):
  return render(request,'sirvasmsapp/404.html')

def error_500(request):
  return render(request,'sirvasmsapp/505.html')
    