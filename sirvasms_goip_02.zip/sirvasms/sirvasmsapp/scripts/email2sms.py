from twilio.rest import Client

import mysql.connector
import base64
import email
import mailparser
import time
import re

# Marrow Mailer
import logging
from marrow.mailer import Message, Mailer
logging.basicConfig(level=logging.DEBUG)

# GoIP Gateway
import requests
import json
import pprint
import re

# Buy and Sell Computation
from decimal import Decimal, getcontext

def goip_send(number,message):
 
    number = number.replace('+639', '09')
  
    url = "http://159.89.201.114/goip/en/dosend.php?USERNAME=root&PASSWORD=smsserver@8888$$&smsprovider=1&goipname=goip1&smsnum=" + number + "&method=2&Memo=" + message
    reply = requests.post(url)

    messageid = re.search(r'messageid=(.*?)&USERNAME',reply.text).group(1)

    send_url = "http://159.89.201.114/goip/en/resend.php?messageid=" + messageid + "&USERNAME=root&PASSWORD=smsserver@8888$$"
    send_reply = requests.post(send_url)
    
    return messageid

def twilio_send(source,number,message):

      account_sid = "ACe4a77d8aa2fc0c6c53d1710010ec6d11"
      auth_token  = "6a2597349081c45d3bfbb577a6a97ce9"
      client = Client(account_sid, auth_token)
      
      try:
          message = client.messages.create(to=number,from_=source,body=message)
          return message.sid
      except:
          return None
        
            
  
def sendSMS(number,message,from_,to):
  
         message_count = message.count('')
         print("###### message_count : " + str(message_count))
      
         if message_count < 306:
  
              if "+63" in number: # PHILIPPINES
                  get_code = "+63"
              elif "+1" in number: # US and CANADA
                  get_code = "+1"
              elif "+65" in number: # SINGAPORE
                  get_code = "+65"
              elif "+971" in number: # UAE 
                  get_code = "+971"
              elif "+852" in number: # HONGKONG
                  get_code = "+852"
              elif "+86" in number: # CHINA
                  get_code = "+86"
              elif "+60" in number: # MALAYSIA
                  get_code = "+60"
              elif "+91" in number: # INDIA
                  get_code = "+91"
              else: # OTHER COUNTRIES
                  get_code = "+000"
                  
              print("###### get_code : " + str(get_code))
                                    

              conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
              cursor = conn.cursor()
              sql = "select route,source,buy,sell from sirvasmsapp_rate WHERE code LIKE '{}%'".format(get_code)
              cursor.execute(sql)
              row = cursor.fetchone()

              if row:
                
                  route = str(row[0])
                  source = str(row[1])
                  buy = str(row[2])
                  sell = str(row[3])  
                  
                  # SMS Computation 
                  if message_count > 160:
                    
                      buy = Decimal(buy) * 2
                      sell = Decimal(sell) * 2
                     
              else: 
                
                  route = source = buy = sell = "None"

              print("###### route : " + str(route))
              print("###### source : " + str(source))
              print("###### buy : " + str(buy))
              print("###### sell : " + str(sell))
                  

              if route == "GSM":
                  messageSid = goip_send(number,message)
                  if messageSid:
                      print("###### messageSid : " + str(messageSid))
                      updateStatus('1',id_)
                      insertEmail(from_, to, number, message, messageSid, buy, sell, route)
                      
              elif route == "Twilio":
                  messageSid = twilio_send(source,number,message)
                  if messageSid:
                      print("###### messageSid : " + str(messageSid))
                      updateStatus('1',id_)
                      insertEmail(from_, to, number, message, messageSid, buy, sell, route)
                  else:
                      print("###### error : Twilio Sending Failed")
                      updateStatus('4',id_)
                      insertEmail(from_, to, number, message, "Failed", "0", "0", route)
                      sendEmail(from_,'SMS Failed  ' + number,'Sending SMS Failed. Please check if the number is correct. ')
                      
              else:
                  print("###### error : Sending Outside Allowed Countries")
                  updateStatus('3',id_)
                  insertEmail(from_, to, number, message, "Blocked", "0", "0", route) 
                  sendEmail(from_,'SMS Failed  ' + number,'Sending SMS Failed because you are sending SMS Outside Allowed Countries')

          
         else:
            
            print("###### error : Character is Too Long")
            updateStatus('2',id_) 
            insertEmail(from_, to, number, message, "Too Long","0","0", "None")
            sendEmail(from_,'SMS Failed  ' + number,'SMS Character is too long ( ' + str(message_count) + ' ).The maximum character per SMS is 306.')
          
          
            
  
def sendEmail(email_id,subject,body):
  
      mail = Mailer({
            'manager.use': 'futures',
            'transport.use': 'smtp',
            'transport.host': 'smtp.gmail.com',
            'transport.tls': 'ssl',
            'transport.username': 'servicehub.sms@gmail.com',
            'transport.password': '09106850351',
            'transport.max_messages_per_connection': 5
          })
      mail.start()

      # message = Message([('ServiceHub', 'joven@telerain.com')], [('Joven Tan', 'jovenntann@gmail.com')], from_number, plain=body)
      message = Message([('ServiceHub', 'servicehub.sms@gmail.com')], [(email_id,email_id)], subject, plain=body)

      mail.send(message)
      mail.stop()

def updateStatus(status,email_id):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
        cursor = conn.cursor()
        sql = "UPDATE django_mailbox_message SET twilio_status = '{}' WHERE id = '{}'".format(status,email_id)
        cursor.execute(sql)
        conn.commit()
        conn.close()
        

        


def insertEmail(from_email, to_email, subject, body, MessageSid, buy, sell, route):
    
        conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
        cursor = conn.cursor()
        sql = "INSERT INTO sirvasmsapp_email (id, from_email, to_email, subject, body, buy, sell, MessageSid, route, date) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP())"
        cursor.execute(sql, ('AUTO',from_email, to_email, subject, body, buy, sell, MessageSid, route))
        conn.commit()
        conn.close()
        


def regex_subject(subject):

      regex = r"([+]|[0-9]){5,20}"
      matches = re.finditer(regex, subject, re.MULTILINE)

      for matchNum, match in enumerate(matches):
          matchNum = matchNum + 1

          return (match.group())
        
# ======================================================================================
# FETCH EMAIL FROM DJANGO_MAIL WHERE TWILIO_STATUS = 0
# ======================================================================================
conn = mysql.connector.Connect(host='localhost',user='root',password='',database='sirva')
cursor = conn.cursor()
sql = "SELECT id,body FROM django_mailbox_message WHERE (from_header LIKE '%@sirva.com%' OR from_header LIKE '%@gmail.com%' OR from_header LIKE '%@starhub.com.ph%')  AND twilio_status = '0' LIMIT 1;" # ALLOWED DOMAIN HERE
cursor.execute(sql)
row = cursor.fetchone()

if row:

      id_ = str(row[0])
      body = str(row[1])

      # =================================================================================
      # DECODE BODY
      # =================================================================================
      decoded = base64.b64decode(body)
      mail = mailparser.parse_from_bytes(decoded)

      # =================================================================================
      # GET EMAIL DATA
      # =================================================================================
      from_ = mail.from_
      from_ = from_[0][1]
      to = mail.to
      to = to[0][1]
      subject = mail.subject
      regex_subject = regex_subject(subject)      
      body = mail.body
      sep = '---'
      body = body.split(sep, 1)[0]
      body =  "(DO NOT REPLY TO THIS MESSAGE).\n\n" + body
      body = body + "\nFrom: " + from_
      print("######")
      print("###### from : " + str(from_))
      print("###### subject : " + str(subject))
      
      if regex_subject:
        
           sendSMS(regex_subject,body,from_,to)
        
      elif regex_subject is None:
            
           print("###### error : Invalid subject")
            
           updateStatus('2',id_) 
           insertEmail(from_, to, subject, body, "Invalid Number","0","0", "None")
           sendEmail(from_,'Invalid Number','Please enter the recipient number on the Subject with Correct format. Eg. +639062131607 if you are sending SMS to Philippine numbers.')
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
      