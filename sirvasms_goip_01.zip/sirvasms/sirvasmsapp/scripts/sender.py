import mysql.connector
import time
import re
import datetime

# GoIP API
import requests
import json
import pprint
import re


def goip_send(number,message):
 
    # number = number.replace('+639', '09')
  
    url = "http://10.20.22.151/goip/en/dosend.php?USERNAME=root&PASSWORD=root&smsprovider=1&goipname=GlobeSim1&smsnum=" + number + "&method=2&Memo=" + message
    reply = requests.post(url)
    print(reply.text)
    messageid = re.search(r'messageid=(.*?)&USERNAME',reply.text).group(1)

    send_url = "http://10.20.22.151/goip/en/resend.php?messageid=" + messageid + "&USERNAME=root&PASSWORD=root"
    send_reply = requests.post(send_url)
    print(send_reply.text)
    return messageid





def insertSMS(MessageSid, date, from_number, to_number, message, user, status):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='09106850351',database='goip')
        cursor = conn.cursor()

        sql = "INSERT INTO sirvasmsapp_sent (id, MessageSid, date, from_number, to_number, user, message, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(sql, ('AUTO', MessageSid, date, from_number, to_number, user, message, status))
        conn.commit()
        conn.close()

def updateStatus(_id,status):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='09106850351',database='goip')
        cursor = conn.cursor()
        sql = "UPDATE sirvasmsapp_queue SET flag = '{}' WHERE id = '{}'".format(status,_id)
        cursor.execute(sql)
        conn.commit()
        conn.close()
        

while True:

        conn = mysql.connector.Connect(host='localhost',user='root',password='09106850351',database='goip')
        cursor = conn.cursor()
        sql = "SELECT * FROM sirvasmsapp_queue WHERE flag = '0' LIMIT 1;" 
        cursor.execute(sql)
        row = cursor.fetchone()

        if row:
        
                id = str(row[0])
                date = str(row[1])
                from_number = str(row[2])
                to_number = str(row[3])
                user = str(row[4])
                message = str(row[5])
                flag = str(row[6])

                MessageSid = goip_send(to_number,message)



                print(id + ' | ' + date + ' | ' + from_number + ' | ' + to_number+ ' | ' + user+ ' | ' + message+ ' | ' + flag)

                insertSMS(MessageSid, date, from_number, to_number, message, user, 'Sent')
                updateStatus(id,1)

































