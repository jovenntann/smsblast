import mysql.connector
import time
import datetime

def insertSMS(date, from_number, to_number, message, MessageSid, status):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='09106850351',database='goip')
        cursor = conn.cursor()

        sql = "INSERT INTO sirvasmsapp_received (id, date, from_number, to_number, message, MessageSid, status) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(sql, ('AUTO', date, from_number, to_number, message, MessageSid, status))
        conn.commit()
        conn.close()

def updateStatus(_id,status):
  
        conn = mysql.connector.Connect(host='localhost',user='root',password='09106850351',database='goip')
        cursor = conn.cursor()
        sql = "UPDATE receive SET flag = '{}' WHERE id = '{}'".format(status,_id)
        cursor.execute(sql)
        conn.commit()
        conn.close()
        

while True:

        conn = mysql.connector.Connect(host='localhost',user='root',password='09106850351',database='goip')
        cursor = conn.cursor()
        sql = "SELECT * FROM receive WHERE flag = '0' LIMIT 1;" 
        cursor.execute(sql)
        row = cursor.fetchone()

        if row:
        
                _id = str(row[0])
                srcnum = str(row[1])
                msg = str(row[3])
                date = str(row[4])

                print(_id + ' | ' + date + ' | ' + srcnum + ' | ' + msg)

                insertSMS(date, srcnum, '09062131607', msg, _id, 'Received')
                updateStatus(_id,1)




