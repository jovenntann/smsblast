import os
import time

while True:
  
  getmail = "python /opt/djangoprojects/sirvasms/manage.py getmail"
  os.system(getmail)

  fetchandsend = "python3.6 /opt/djangoprojects/sirvasms/sirvasmsapp/scripts/email2sms.py"
  os.system(fetchandsend)
  
  goipgetandsend = "python /opt/djangoprojects/sirvasms/sirvasmsapp/scripts/goip2email.py"
  os.system(goipgetandsend)
