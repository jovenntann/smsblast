# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models

# Default Authentication
from django.contrib.auth.models import User
import datetime

class Received(models.Model):
    date = models.DateTimeField()
    from_number = models.CharField(max_length=80)
    to_number = models.CharField(max_length=80)
    message = models.CharField(max_length=1000)
    MessageSid = models.CharField(max_length=80)
    status = models.CharField(max_length=80)
    
    def __str__(self):
        return str(self.message)

class Sent(models.Model):
    MessageSid = models.CharField(max_length=80)
    date = models.DateTimeField(auto_now_add=True)
    from_number = models.CharField(max_length=1000)
    to_number =  models.CharField(max_length=1000)
    user = models.CharField(max_length=80)
    message = models.CharField(max_length=1000)
    status = models.CharField(max_length=80)
    
    def __str__(self):
        return str(self.message)

class Queue(models.Model):
    date = models.DateTimeField(auto_now_add=True)
    from_number = models.CharField(max_length=1000)
    to_number =  models.CharField(max_length=1000)
    user = models.CharField(max_length=80)
    message = models.CharField(max_length=1000)
    flag = models.BooleanField(default=False)

    def __str__(self):
        return str(self.message)
      
class DateRange(models.Model):
    user = models.ForeignKey(User)
    date_from = models.DateField()
    date_to = models.DateField()

    def __str__(self):
        return str(self.user)   
      
class Rate(models.Model):
    code = models.CharField(max_length=10)
    abbreviation = models.CharField(max_length=4)
    country = models.CharField(max_length=50)
    buy = models.DecimalField(max_digits=8, decimal_places=6)
    sell = models.DecimalField(max_digits=8, decimal_places=6)
    route = models.CharField(max_length=20)
    source = models.CharField(max_length=20)
    
    def __str__(self):
        return str(self.country)